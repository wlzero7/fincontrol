<?php

$host = "sql113.infinityfree.com";
$dbname = "if0_42092187_fincontrol";
$user = "if0_42092187";
$pass = "38858669Wi@";

try {

    $pdo = new PDO(
        "mysql:host=$host;dbname=$dbname;charset=utf8mb4",
        $user,
        $pass
    );

    $pdo->setAttribute(
        PDO::ATTR_ERRMODE,
        PDO::ERRMODE_EXCEPTION
    );

} catch(PDOException $e){

    die("Erro de conexão: " . $e->getMessage());

}